/* global module */
/* global require */
require('should');
const loader = require("esm")(module);
loader('./v3-test.js');

